import json
from utils import visualization_utils as vis_util
from utils import label_map_util
import PIL
from PIL import Image
from matplotlib import pyplot as plt
from io import StringIO
from collections import defaultdict
import pyodbc
import time
import zipfile
import numpy as np
import os
import six.moves.urllib as urllib
import sys
import tarfile
import tensorflow.compat.v1 as tf
import pytesseract, re
import argparse
import cv2
import os
import itertools
import shutil
import maskin2 as ms
from datetime import datetime
import demo_tesseract as ts
import gc
import pathlib
from os import path
tf.disable_v2_behavior()
import logging
#from pytransform import pyarmor_runtime
#import pytransform
#from cryptography.fernet import Fernet
#import encrypt_username as enu
#import encrypt_password as enp
import aadhar_ocr_text_extract as ext


sys.path.append("..")


MODEL_NAME = 'new_graph'  # change to whatever folder has the new graph

PATH_TO_CKPT = MODEL_NAME + '/frozen_inference_graph.pb'

PATH_TO_LABELS = os.path.join('training', 'labelmap.pbtxt')

NUM_CLASSES = 15

j = 0
c_images = 0
image_id = 0
lastimg = "No Image"

logging.basicConfig(filename='D:/tanmay/tensorflow/models/research/object_detection/Error.log', level=logging.DEBUG, 
                    format='%(asctime)s %(levelname)s %(name)s %(message)s')
logger=logging.getLogger(__name__)


detection_graph = tf.Graph()
with detection_graph.as_default():
    od_graph_def = tf.GraphDef()
    with tf.gfile.GFile(PATH_TO_CKPT, 'rb') as fid:
        serialized_graph = fid.read()
        od_graph_def.ParseFromString(serialized_graph)
        tf.import_graph_def(od_graph_def, name='')




label_map = label_map_util.load_labelmap(PATH_TO_LABELS)
categories = label_map_util.convert_label_map_to_categories(
    label_map, max_num_classes=NUM_CLASSES, use_display_name=True)
category_index = label_map_util.create_category_index(categories)


def load_image_into_numpy_array(image):
    if image.mode != 'RGB':
        image = image.convert('RGB')
    (im_width, im_height) = image.size
    return np.array(image.getdata()).reshape((im_height, im_width, 3)).astype(np.uint8)


def decrypt(key, message):
    message = message
    alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$=+&"
    result = ""

    for letter in message:
        if letter in alpha: #if the letter is actually a letter
            #find the corresponding ciphertext letter in the alphabet
            letter_index = (alpha.find(letter) - key) % len(alpha)

            result = result + alpha[letter_index]
        else:
            result = result + letter
    return result

def image_rotate(image_path, masked_outputPath):
    im = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
    # Compute difference between each two color channels for finding colored pixels.
    cdiff = cv2.absdiff(im[:,:,0], im[:,:,1])//3 + cv2.absdiff(im[:,:,0], im[:,:,2])//3 + cv2.absdiff(im[:,:,1], im[:,:,2])//3;
    ret, cmask = cv2.threshold(cdiff, 10, 255, cv2.THRESH_BINARY)
    
    # Find clusters.
    # https://answers.opencv.org/question/194566/removing-noise-using-connected-components/
    nlabel,labels,stats,centroids = cv2.connectedComponentsWithStats(cmask, connectivity=8)
    
    # Find second largest cluster (the largest is the background?):
    stats[np.argmax(stats[:, cv2.CC_STAT_AREA])] = 0
    idx_max_size = np.argmax(stats[:, cv2.CC_STAT_AREA])
    center = centroids[idx_max_size]
    
    # True if the center of the centroid is at the right side of the image
    is_center_at_right_side = center[0] > im.shape[1]//2
    
    if is_center_at_right_side:
        rotated_im = im[::-1, ::-1, :].copy()  # Reverse left/right and up/down
        fname = image_path.split('\\')
        #print(fname)
        fname1 =  fname[-1].split(".")
        cv2.imwrite(masked_outputPath + fname1[0] +'.jpg',im)
        #cv2.imshow('rotated_im', rotated_im)
        #cv2.waitKey(0)
        
    # Draw green circle at the center (for testing)
    #cv2.circle(im, (int(center[0]), int(center[1])), 10, (0, 255, 0), thickness=10)
    
    #cv2.imshow('cmask', cmask)
    #cv2.imshow('im', im)
    #cv2.waitKey(0)
    
    if is_center_at_right_side:
        rotated_im = cv2.rotate(im, cv2.ROTATE_90_COUNTERCLOCKWISE)
        fname = image_path.split('\\')
        #print(fname)
        fname1 =  fname[-1].split(".")
        #print(fname1)
    
        #cv2.destroyAllWindows()
        cv2.imwrite(masked_outputPath + fname1[0] +'.jpg',rotated_im)
    else:
        rotated_im = cv2.rotate(im, cv2.ROTATE_90_CLOCKWISE)
        fname = image_path.split('\\')
        #print(fname)
        fname1 =  fname[-1].split(".")
        #print(fname1)
    
        #cv2.destroyAllWindows()
        cv2.imwrite(masked_outputPath + fname1[0] +'.jpg',rotated_im)

IMAGE_SIZE = (12, 8)

try:
    server = '10.10.101.23,4554'
    database = 'CKYCIMAGE'
    username = 'KYCVERIFYSRVUSRon'
    
    word = "w7FX1D71GB789"
    decrypted = decrypt(6,word)
    password = decrypted


    cnxn = pyodbc.connect('DRIVER={SQL Server Native Client 11.0};SERVER=' +
                          server+';DATABASE='+database+';UID='+username+';PWD=' + password,autocommit=True)
    cursor = cnxn.cursor()
    

    #print("Length is : ",len(records_pending))
    exc = 0
    num_exc = 0
    images_done = ["No Image","NO IMAGE","no image"]
    lastimg = "No Image"
    current_file = "No Image"
    ignored_files = []
    loop = 0
    cnt = 0


    def OCR_IMAGE(file_path):
        try:
            image = cv2.imread(file_path)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            

            cv2.imwrite(filename, gray)
            regex = ("^[2-9]{1}[0-9]{3}\\" +
                        "s[0-9]{4}\\s[0-9]{4}$")
            p = re.compile(regex)
            #str1 = "uidai"
            
            
            # the temporary file
            out = pytesseract.image_to_string(Image.open(filename))
            os.remove(filename)
            #print(out)
            paragraph = out.split('\n')
            check_aadhar = 0
            
            for text in paragraph:
                if(re.search(p, text)):
                    #print('Success')
                    check_aadhar += 1
                if('uidai' in text.lower()):
                    check_aadhar += 1
                if('government of india' in text.lower()):
                    check_aadhar += 1
                if('aadhaar' in text.lower()):
                    check_aadhar += 1
                if('vid' in text.lower()):
                    check_aadhar += 1
                if('unique identification' in text.lower()):
                    check_aadhar += 1
                if('www.uid.com' in text.lower()):
                    check_aadhar += 1
                if('dob' in text.lower()):
                    check_aadhar += 1
                if('year of birth' in text.lower()):
                    check_aadhar += 1
                if('enrollment no' in text.lower()):
                    check_aadhar += 1
            return check_aadhar
            
        except Exception as er:
            logger.error(er)
            print("OCR Function:",er)
            return 0


    while loop == 0:
        input_query = "select id,savefilepath,CustomerID,UID_NUMBER,OCR_Counter from v_pyMaskData where IS_MASK = 'P'"
        cursor.execute(input_query)
        input_folders = cursor.fetchall()


        for row in input_folders:
            
            try:
                folder_id = row[0]
                images_path = row[1] + "\\" 
                print("Input path:", images_path)
                cust_id = row[2]
                masked_outputPath = row[1] +"\\"
                print("Output path:", masked_outputPath)
                uidnum = row[3]
                images_done = []
                mask_type = []
                ocr_countr=row[4]

                with detection_graph.as_default():
                    with tf.Session(graph=detection_graph) as sess:
                        i = 0
                        PATH_TO_TEST_IMAGES_DIR = images_path
                        total_files = os.listdir(PATH_TO_TEST_IMAGES_DIR) # dir is your directory path
                        number_files = len(total_files)
                        
                        #PATH_TO_TEST_IMAGES_DIR = 'D:/Inayat/finalModel/tensorflow/models/research/object_detection/test_images'
                        # TEST_IMAGE_PATHS = [os.path.join(PATH_TO_TEST_IMAGES_DIR, 'tst ({}).jpg'.format(i)) for i in range(1, 5)]  # adjust range for # of images in folder
                        images = []
                        
                        for filename in os.listdir(PATH_TO_TEST_IMAGES_DIR):
                            image_path = os.path.join(PATH_TO_TEST_IMAGES_DIR, filename)
                            # rint(filename)

                            if image_path is not None:
                                try:
                                    fname = image_path.split('\\')
                                    file_name = fname[-1]
                                    print("Step 1 fl:",file_name.lower())
                                    #print("Customer id:",folder_id)
                                    if 'aadhaar' in file_name.lower() and not 'masked' in file_name.lower():# and folder_id in file_name.lower():
                                        number_coordinates = []
                                        image = Image.open(image_path)
                                            # the array based representation of the image will be used later in order to prepare the
                                            # result image with boxes and labels on it.
                                        image_np = load_image_into_numpy_array(image)
                                        # Expand dimensions since the model expects images to have shape: [1, None, None, 3]
                                        image_np_expanded = np.expand_dims(image_np, axis=0)
                                        image_tensor = detection_graph.get_tensor_by_name('image_tensor:0')
                                        # Each box represents a part of the image where a particular object was detected.
                                        boxes = detection_graph.get_tensor_by_name('detection_boxes:0')
                                        # Each score represent how level of confidence for each of the objects.
                                        # Score is shown on the result image, together with the class label.
                                        scores = detection_graph.get_tensor_by_name('detection_scores:0')
                                        classes = detection_graph.get_tensor_by_name('detection_classes:0')
                                        num_detections = detection_graph.get_tensor_by_name(
                                            'num_detections:0')
                                        # Actual detection.
                                        (boxes, scores, classes, num_detections) = sess.run(
                                            [boxes, scores, classes, num_detections],
                                            feed_dict={image_tensor: image_np_expanded})
                                        # Visualization of the results of a detection.
                                        vis_util.visualize_boxes_and_labels_on_image_array(
                                            image_np,
                                            np.squeeze(boxes),
                                            np.squeeze(classes).astype(np.int32),
                                            np.squeeze(scores),
                                            category_index,
                                            use_normalized_coordinates=True,
                                            line_thickness=8,
                                            min_score_thresh=0.65)

                                        plt.figure(figsize=IMAGE_SIZE)
                                        # matplotlib is configured for command line only so we save the outputs instead
                                        plt.imshow(image_np)
                                        # create an outputs folder for the images to be saved
                                        
                                        fname = image_path.split('\\')
                                        createfolder = pathlib.Path(PATH_TO_TEST_IMAGES_DIR+"\\"+"_outputs\\")
                                        print(createfolder)

                                        if createfolder.exists():
                                            print("Output folder exists")
                                        else:
                                            os.makedirs(PATH_TO_TEST_IMAGES_DIR+"\\"+"_outputs\\")
                                        
                                        #os.makedirs(PATH_TO_TEST_IMAGES_DIR+"\\"+"outputs\\")
                                        #print()
                                        plt.savefig(PATH_TO_TEST_IMAGES_DIR+"\\"+"_outputs\\"+fname[-1])
                                        

                                        
                                        coordinates = vis_util.return_coordinates(
                                            image_np,
                                            np.squeeze(boxes),
                                            np.squeeze(classes).astype(np.int32),
                                            np.squeeze(scores),
                                            category_index,
                                            use_normalized_coordinates=True,
                                            line_thickness=8,
                                            min_score_thresh=0.65)
                                        '''
                                        fname = image_path.split('\\')
                                        file_name = fname[-1]
                                        print("Step 1 fl:",file_name.lower())
                                        if 'aadhaar' in file_name.lower() and not 'masked' in file_name.lower():
                                        '''
                                        total_boxes = len(coordinates)
                                        #file_name, file_extension = os.path.splitext(image_path)
                                        print("filename:",file_name)
                                        extension = pathlib.Path(image_path).suffix
                                        print("Extension of file :",extension)

                                        for x in range(0, total_boxes):
                                            if 'a_number' in str(coordinates[x]):
                                                number_coordinates.append(coordinates[x])
                                                
                                        num_uid = ts.doTesseract(image_path,number_coordinates)
                                        num_uid1 = ext.aadhaar_extract(image_path)
                                        print("From Tesseract:",num_uid1)
                                        print("From coordinate:",num_uid)

                                        # when data extraction is none from both OCR extraction
                                        # Case may be image might be rotated
                                        # So check for OCR data and apply rotation method
                                        if num_uid1 == None and len(num_uid) == 0:
                                            print("Image Rotate")
                                            image_rotate(image_path, masked_outputPath)

                                        else:
                                            update_query = """Update tbl_AutoCatgDocsDetails set OCR_Counter = OCR_Counter+1 where id = ?"""
                                            update_data = (folder_id)
                                            cursor.execute(update_query, update_data)
                                            cnxn.commit()

                                        try:
                                            if ocr_countr < 2:
                                                try:
                                                    if num_uid != None:
                                                        for x in num_uid:
                                                            data_test = x.split(" ")
                                                            if data_test[0:3] != None:
                                                                print("Extracted data:",data_test[0:3])
                                                                #print("Extracted data:",data_test)
                                                                print("OCR Data :",data_test[0],data_test[1],data_test[2])
                                                                print("Original data :",uidnum[0:4],uidnum[4:8],uidnum[8:12])
                                                                if len(data_test[0]) != None:
                                                                    isMatch = False
                                                                    print(data_test[0])
                                                                    print(uidnum[0:4])
                                                                    if data_test[0] == uidnum[0:4]:
                                                                        print("match Success")
                                                                        mask_type = "Y"
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    else:
                                                                        print("match Failed")
                                                                        isMatch = False

                                                                elif len(data_test[1]) != None:
                                                                    print(data_test[1])
                                                                    print(uidnum[4:8])
                                                                    if data_test[1] == uidnum[4:8]:
                                                                        print("match Success")
                                                                        mask_type = "Y"
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    else:
                                                                        print("match Failed")
                                                                        isMatch = False

                                                                elif len(data_test[2]) != None:
                                                                    print(data_test[2])
                                                                    print(uidnum[8:12])
                                                                    if data_test[2] == uidnum[8:12]:
                                                                        print("match Success")
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    else:
                                                                        print("match Failed")
                                                                        isMatch = False

                                                            elif data_test[0:2] != None:
                                                                print("Extracted data:",data_test[0:2])
                                                                #print("Extracted data:",data_test)
                                                                print("OCR Data :",data_test[0],data_test[1])
                                                                print("Original data :",uidnum[0:4],uidnum[4:8])
                                                                if len(data_test[0]) != None:
                                                                    isMatch = False
                                                                    
                                                                    if data_test[0] == uidnum[0:4]:
                                                                        print(data_test[0])
                                                                        print(uidnum[0:4])
                                                                        print("match Success")
                                                                        mask_type = "Y"
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    elif data_test[0] == uidnum[4:8]:
                                                                        print(data_test[0])
                                                                        print(uidnum[4:8])
                                                                        print("match Success")
                                                                        mask_type = "Y"
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    elif data_test[0] == uidnum[8:12]:
                                                                        print(data_test[0])
                                                                        print(uidnum[8:12])
                                                                        print("match Success")
                                                                        mask_type = "Y"
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    else:
                                                                        print("match Failed")
                                                                        isMatch = False

                                                                elif len(data_test[1]) != None:
                                                                    isMatch = False
                                                                    if data_test[1] == uidnum[4:8]:
                                                                        print(data_test[1])
                                                                        print(uidnum[4:8])
                                                                        print("match Success")
                                                                        mask_type = "Y"
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    elif data_test[1] == uidnum[4:8]:
                                                                        print(data_test[1])
                                                                        print(uidnum[4:8])
                                                                        print("match Success")
                                                                        mask_type = "Y"
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    elif data_test[1] == uidnum[8:12]:
                                                                        print(data_test[1])
                                                                        print(uidnum[8:12])
                                                                        print("match Success")
                                                                        mask_type = "Y"
                                                                        isMatch = True
                                                                        ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    else:
                                                                        print("match Failed")
                                                                        isMatch = False

                                                    elif num_uid1 != None:
                                                        if num_uid1[0] != None:
                                                            print("Full OCR")
                                                            print("OCR Data :", num_uid1[0])
                                                            print("Original data :",uidnum[0:4],uidnum[4:8],uidnum[8:12])

                                                            if num_uid1[0][0:4] != None:
                                                                if num_uid1[0][0:4] == uidnum[0:4]:
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    isMatch = True
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                else:
                                                                    print("match Failed")
                                                                    isMatch = False

                                                            elif num_uid1[0][5:9] != None:
                                                                if num_uid1[0][5:9] == uidnum[4:8]:
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    isMatch = True
                                                                else:
                                                                    print("match Failed")
                                                                    isMatch = False

                                                            elif num_uid1[0][10:14] != None:
                                                                if num_uid1[0][10:14] == uidnum[8:12]:
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    isMatch = True
                                                                else:
                                                                    print("match Failed")
                                                                    isMatch = False

                                                        elif num_uid1[0][0:9] != None:
                                                            print("Full OCR")
                                                            print("OCR Data :", num_uid1[0][0:9])
                                                            print("Original data :",uidnum[0:4],uidnum[4:8],uidnum[8:12])

                                                            if num_uid1[0][0:4] != None:
                                                                if num_uid1[0][0:4] == uidnum[0:4]:
                                                                    print(num_uid1[0][0:4])
                                                                    print(uidnum[0:4])
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    isMatch = True
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)

                                                                elif num_uid1[0][0:4] == uidnum[4:8]:
                                                                    print(num_uid1[0][0:4])
                                                                    print(uidnum[4:8])
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    isMatch = True
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                elif num_uid1[0][0:4] == uidnum[8:12]:
                                                                    print(num_uid1[0][0:4])
                                                                    print(uidnum[8:12])
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    isMatch = True
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)   
                                                                else:
                                                                    print("match Failed")
                                                                    isMatch = False

                                                            elif num_uid1[0][5:9] != None:
                                                                if num_uid1[0][5:9] == uidnum[0:4]:
                                                                    print(num_uid1[0][5:9])
                                                                    print(uidnum[0:4])
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    isMatch = True
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                elif num_uid1[0][5:9] == uidnum[4:8]:
                                                                    print(num_uid1[0][5:9])
                                                                    print(uidnum[4:8])
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    isMatch = True
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    
                                                                elif num_uid1[0][5:9] == uidnum[8:12]:
                                                                    print(num_uid1[0][5:9])
                                                                    print(uidnum[8:12])
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    isMatch = True
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                else:
                                                                    print("match Failed")
                                                                    isMatch = False

                                                            elif num_uid1[0][10:14] != None:
                                                                if num_uid1[0][10:14] == uidnum[8:12]:
                                                                    print("match Success")
                                                                    mask_type = "Y"
                                                                    ms.mask(image_path,number_coordinates,masked_outputPath,mask_type)
                                                                    isMatch = True
                                                                else:
                                                                    print("match Failed")
                                                                    isMatch = False

                                                    if isMatch == True:
                                                        mask_type = "Y"
                                                        update_query = """Update tbl_AutoCatgDocsDetails set IS_MASK = 'C', OCR_Counter = OCR_Counter+1 where id = ?"""
                                                        update_data = (folder_id)
                                                        cursor.execute(update_query, update_data)   
                                                        cnxn.commit()
                                                    else:
                                                        update_query = """Update tbl_AutoCatgDocsDetails set IS_MASK = 'F' where id = ?"""
                                                        update_data = (folder_id)
                                                        cursor.execute(update_query, update_data)   
                                                        cnxn.commit()


                                                except Exception as e:
                                                    logger.error(e)
                                                    print("Exception is : ", e)

                                            else:
                                                print("Tried OCR twice exit from loop")
                                                #print("match Failed")
                                                if ocr_countr==0 or ocr_countr==1:
                                                    update_query = """Update tbl_AutoCatgDocsDetails set OCR_Counter = OCR_Counter+1 where id = ?"""
                                                    update_data = (folder_id)
                                                    cursor.execute(update_query, update_data)
                                                    cnxn.commit()
                                                else:
                                                    update_query = """Update tbl_AutoCatgDocsDetails set IS_MASK = 'F' where id = ?"""
                                                    update_data = (folder_id)
                                                    cursor.execute(update_query, update_data)
                                                    cnxn.commit()
                                        except Exception as e:
                                            logger.error(e)
                                            print("Conter loop error:", e)      

                                    '''        
                                    anumber = 0
                                    aadhar_number = 0
                                    for x in range(0, total_boxes):
                                        if 'a_number' in str(coordinates[x]) :
                                            number_coordinates.append(coordinates[x])
                                            aadhar_number += 1
                                            is_aadhar = "Yes"
                                        #print("numbers are : ",coordinates[x])
                                        #print("numbers are : ",number_coordinates)
                                        coordinates[x] = str(coordinates[x]).replace('[', '')
                                        coordinates[x] = str(coordinates[x]).replace(']', '')
                                        coordinates[x] = str(coordinates[x]).replace(' ', '')
                                        coordinates[x] = str(coordinates[x]).replace("'", '')
                                        # print(coordinates[x])
                                        cord = coordinates[x].split(',')
                                        #print(cord[-1])
                                        res = cord[-1].split(':')
                                        #print(res)
                                        accurracy = str(res[1])
                                        box = str(res[0])
                                        #print("box is:",box)
                                        #print("acc is:",accurracy)
                                        
                                        if box == "a_number":
                                            anumber +=1


                                    print(fname[-1])
                                    print("Total Boxes are : ",total_boxes)
                                    #print("usfront : ",usfront)
                                    #print("usback : ",usback)
                                    #print("ulfront : ",ulfront)
                                    #print("ulback : ",ulback)
                                    #print("ulfull : ",ulfull)
                                    #print("uefull : ",uefull)
                                    #print("ueright : ",ueright)
                                    #print("ueleft : ",ueleft)
                                    print("a_number :",anumber)


                                    if anumber > 0:
                                        checkAadhar = OCR_IMAGE(image_path)
                                        print("Checking OCR data")



                                    else:
                                        print("aadhaar not in filename")
                                    '''      
                                    gc.collect()
                                except KeyboardInterrupt as key:
                                    logger.error(key)
                                    print("Program is inturrupted by keyboard")
                                    if len(ignored_files) > 0:
                                        print("Due To Exception These Files Are Ignored : ",ignored_files)
                                    exit()

                                except Exception as e:
                                    logger.error(e)
                                    print("Exception is : ",e)
                                    exc = 1
                                    num_exc += 1
                                    number_files = number_files - 1
                                    #current_file = images_done[-1]
                                    igfname = image_path.split('\\')
                                    current_file = igfname[-1]
                                    ignored_files.append(current_file)
                                    print("Exception in current file, Ignoring current file", current_file)
                                    #f = open("errorlog.txt","a+")
                                    #f.write(fname[-1]+"\n"+e)
                                    #f.close()
                                    continue

                print("Opertation Completed Successfully On : ",images_path)
                print("")
                print("")
                print("")
                                        
                    
                gc.collect()


            except Exception as ex1:
                logger.error(ex1)
                print("Exception in folder loop : ",ex1)
                
        loop = 1
        input_query2 = 'select id,savefilepath,CustomerID,UID_NUMBER from v_pyMaskData '
        cursor.execute(input_query2)
        input_folders2 = cursor.fetchall()
        if len(input_folders2) == 0:
            print("Could not find any folder to perform operation 2")
            loop = 1
        else:
            loop = 0
        
    cursor.close()
    cnxn.close()
    gc.collect()
except Exception as e:
    logger.error(e)
    print('Outer Exception : ',e)
